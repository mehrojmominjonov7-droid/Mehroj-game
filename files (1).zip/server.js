// Stikman Party Online — serversiz kutubxonalarsiz (faqat Node.js 16+). Ishga tushirish: node server.js
const http = require('http'), fs = require('fs'), path = require('path');
const ORDER = ['tap', 'run', 'catch', 'react'], DUR = { tap: 10, run: 20, catch: 20, react: 9 };
const COL = ['#e63946', '#2a6fdb', '#2dc653', '#ffb703'], rooms = {};
const html = () => fs.readFileSync(path.join(__dirname, 'index.html'));
const room = c => rooms[c] || (rooms[c] = { ps: {}, host: null, round: -1, phase: 'lobby', done: {}, act: [] });
function bc(r, m, except) { const d = 'data: ' + JSON.stringify(m) + '\n\n'; for (const id in r.ps) if (id !== except) r.ps[id].res.write(d); }
function lobby(r) {
  bc(r, { t: 'lobby', host: r.host, ps: Object.entries(r.ps).map(([id, p]) => ({ id, name: p.name, color: p.color, pts: p.pts })) });
}
const alld = r => r.act.filter(i => r.ps[i]).every(i => i in r.done);
function finish(r) {
  if (r.phase !== 'play') return;
  clearTimeout(r.timer); r.phase = 'result';
  const g = ORDER[r.round], bad = g === 'react' ? 9999 : 0;
  const arr = r.act.filter(i => r.ps[i]).map(id => ({ id, s: r.done[id] ?? bad }));
  arr.sort((a, b) => g === 'react' ? a.s - b.s : b.s - a.s);
  arr.forEach((x, i) => { const p = r.ps[x.id]; p.pts += Math.max(0, 3 - i); x.pts = p.pts; x.name = p.name; });
  const last = r.round >= ORDER.length - 1;
  bc(r, { t: 'result', game: g, list: arr, last });
  if (last) r.round = -1;
  r.phase = 'lobby'; lobby(r);
}
http.createServer((q, s) => {
  const u = new URL(q.url, 'http://x');
  if (u.pathname === '/events') {
    const c = (u.searchParams.get('room') || 'MAIN').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'MAIN', r = room(c);
    if (Object.keys(r.ps).length >= 4) { s.writeHead(403).end('Xona to\'la'); return; }
    const id = Math.random().toString(36).slice(2, 8);
    s.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    r.ps[id] = { res: s, name: (u.searchParams.get('name') || 'Stikman').slice(0, 12), pts: 0,
      color: COL.find(k => !Object.values(r.ps).some(p => p.color === k)) };
    if (!r.host) r.host = id;
    s.write('data: ' + JSON.stringify({ t: 'hello', id, room: c }) + '\n\n');
    lobby(r);
    const ka = setInterval(() => s.write(':\n\n'), 25000);
    q.on('close', () => {
      clearInterval(ka); delete r.ps[id];
      if (r.host === id) r.host = Object.keys(r.ps)[0] || null;
      if (!r.host) { clearTimeout(r.timer); delete rooms[c]; return; }
      lobby(r); if (r.phase === 'play' && alld(r)) finish(r);
    });
    return;
  }
  if (u.pathname === '/send' && q.method === 'POST') {
    let b = ''; q.on('data', d => { b += d; if (b.length > 4000) q.destroy(); });
    q.on('end', () => {
      try {
        const m = JSON.parse(b), r = rooms[m.room];
        if (r && r.ps[m.id]) {
          if (m.t === 'state') bc(r, { t: 'state', id: m.id, s: m.s }, m.id);
          else if (m.t === 'start' && r.host === m.id && r.phase === 'lobby') {
            if (r.round === -1) for (const i in r.ps) r.ps[i].pts = 0;
            r.round++; r.phase = 'play'; r.done = {}; r.act = Object.keys(r.ps);
            const g = ORDER[r.round];
            bc(r, { t: 'start', game: g, seed: Math.random() * 1e9 | 0, round: r.round + 1, rounds: ORDER.length, delay: 3500 });
            r.timer = setTimeout(() => finish(r), (DUR[g] + 8) * 1000);
          } else if (m.t === 'done' && r.phase === 'play' && r.act.includes(m.id)) {
            r.done[m.id] = Math.max(0, Math.min(99999, +m.score || 0));
            if (alld(r)) finish(r);
          }
        }
      } catch (e) {}
      s.writeHead(204).end();
    });
    return;
  }
  s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }).end(html());
}).listen(process.env.PORT || 3000, () => console.log('Tayyor: http://localhost:' + (process.env.PORT || 3000)));
