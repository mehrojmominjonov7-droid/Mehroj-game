# Stikman Party Online

2–4 kishi internet orqali bir xonada o'ynaydi. Hech qanday kutubxona kerak emas.

## Ishga tushirish
1. Node.js 16+ o'rnating.
2. `server.js` va `index.html` bir papkada bo'lsin.
3. `node server.js` → http://localhost:3000
4. Xona oching, havolani do'stlarga yuboring.

## Internetga chiqarish
Render.com / Railway / VPS ga yuklang (start buyrug'i: `node server.js`). Do'stlar manzil orqali kiradi.

## O'yinlar
Tez bos (Space/tegish), Sakrash poygasi (Space/tegish), Mevalar (←/→ yoki barmoq bilan surish), Reaksiya (yashil bo'lganda Space).
